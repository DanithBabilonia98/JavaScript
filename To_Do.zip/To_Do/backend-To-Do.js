/**
 * Listado de tareas (To-Do)
 *
 * Estructura de una tarea
 * - {id: 1 , nombre: 'Tarea 1', completado: true, fecha: '01/01/2020'},
 * - {id: 2, nombre: 'Tarea 2', completado: true, fecha: '01/01/2020'},
 * - {id: 3, nombre: 'Tarea 3', completado: true, fecha: '01/01/2020'},
 *
 * Funcionalidades de nuestra app de tareas
 * - Crear tareas
 * - Buscar tarea por nombre
 * - Borrar tareas
 * - Listar tareas
 * - Editar tareas
 */
let tareas = [
  { id: 1, nombre: 'Tarea 1', completado: false, fecha: '2020-01-01' },
  { id: 2, nombre: 'Tarea 2', completado: true, fecha: '2020-05-01' },
  { id: 3, nombre: 'Tarea 3', completado: false, fecha: '2020-01-01' },
];

function crearTarea(nombre, fecha) {
  let id = tareas.length + 1;
  let tarea = {
    id,
    nombre,
    completado: false,
    fecha,
  };
  tareas.push(tarea);
}

function buscarTareaPorNombre(nombre) {
  let tarea = null;
  for (let i = 0; i < tareas.length; i++) {
    let tareaActual = tareas[i];

    if (tareaActual.nombre.toLocaleLowerCase() === nombre.toLocaleLowerCase()) {
      tarea = tareaActual;
      break;
    }
  }

  return tarea;
}

function borrarTarea(id) {
  for (let i = 0; i < tareas.length; i++) {
    if (tareas[i].id === id) {
      tareas.splice(i, 1);
    }
  }
  listarTareas();
}

function editarTarea(id, nuevoNombre, estado) {
  for (let i = 0; i < tareas.length; i++) {
    if (tareas[i].id === id) {
      tareas[i].nombre = nuevoNombre;
      tareas[i].completado = estado;
    }
  }
}

/**
 * Integracion
 */
let tablaListadoTareas = document.getElementById('listado-tareas');

function listarTareas() {
  let filasTabla = ``;
  for (let i = 0; i < tareas.length; i++) {
    let { id, nombre, fecha, completado } = tareas[i];
    let badged = '';

    if (completado) {
      badged = "<span class='badge bg-success'>Completado</span>";
    } else {
      badged = "<span class='badge bg-warning text-dark'>Pendiente</span>";
    }

    filasTabla += `
      <tr>
        <th scope="row">${id}</th>
        <td>${nombre}</td>
        <td>${badged}</td>
        <td>${fecha}</td>
        <td>
          <button type="button" class="btn btn-outline-primary btn-sm" onclick="actualizarTarea(${id})">Editar</button>
          
          <button type="button" class="btn btn-sm btn-outline-danger" onclick="borrarTarea(${id})">Eliminar</button>
        </td>
      </tr>
    `;
  }

  tablaListadoTareas.innerHTML = filasTabla;
}

/**
 * Crear tarea integracion
 */
let btnCrearTarea = document.getElementById('btnCrearTarea');

btnCrearTarea.addEventListener('click', function (e) {
  let formularioCrearTarea = document.getElementById('crear-tarea');

  let { nombre, fecha } = formularioCrearTarea.elements;

  crearTarea(nombre.value, fecha.value);
  formularioCrearTarea.reset();

  listarTareas();
});

/**
 * Actualizar tarea
 */
function actualizarTarea(id) {
  let nombre = prompt('Ingrese el nuevo nombre:');
  let estado = prompt('Ingrese el nuevo estado:');
  let completado = false;

  if (estado === 'true') {
    completado = true;
  }

  editarTarea(id, nombre, completado);
  listarTareas();
}

listarTareas();
