/**
 * Dudas:
 *  - Obtener el primer digito
 */
function obtenerPrimerDigito(numero) {
  return numero.toString()[0];
}

/* let cadena = 'Hola mundo';
console.log(cadena[0]);
'25'[0] */

console.log(obtenerPrimerDigito(25));

function obtenerPrimerDigito0(numero) {
  let cantidadDigitos = numero.toString()[0].length;
  let primerDigito = numero / parseFloat(`1e${cantidadDigitos}`);
  return parseInt(primerDigito);
}

console.log(obtenerPrimerDigito0(25));

function obtenerPrimerDigito1(numero) {
  let numeroOriginal = numero;
  let cantidadDigitos = 0;

  while (numero > 0) {
    numero = parseInt(numero / 10);
    cantidadDigitos++;
  }

  let primerDigito = numeroOriginal / parseFloat(`1e${cantidadDigitos - 1}`);

  return parseInt(primerDigito);
}

console.log(obtenerPrimerDigito1(652234562156451256));

function obtenerPrimerDigito2(numero) {
  let primerDigito = 0;

  while (numero > 0) {
    primerDigito = numero % 10;
    numero = parseInt(numero / 10);
  }

  return primerDigito;
}

/**
 * n => 520
 * pd => 520 % 10 = 0
 * n => 520 / 10 = 52
 * pd => 52 % 10 = 2
 * n => 52 / 10 = 5
 * pd => 5 % 10 = 5
 * n => 5 / 10 = 0
 *
 * pd => 5
 */

console.log(obtenerPrimerDigito2(520));
