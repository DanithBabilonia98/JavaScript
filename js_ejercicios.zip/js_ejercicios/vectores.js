/* let usuario = {
  cedula: '123456789',
}
 */

// let arreglo = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let arreglo = ['hola', 2021, true, 'adios', 2020, false];

console.log(arreglo);

console.log(arreglo[1]);

console.log(arreglo[5]);

console.log(arreglo[4]);

let numeros = [10, 20]; // declaracion de una lista
console.log(numeros.length);
//  numeros === [1, 2] => false

console.log(numeros.toString());
console.log(typeof numeros.toString());
console.log(Infinity);

// agregamos elementos al final del arreglo
numeros.push(30);
numeros.push(40);
numeros.push(50);
numeros.push(60);

//
console.log(numeros.length);
console.log(numeros);

let acumulador = 0;

for (let i = 0; i < numeros.length; i++) {
  let elemento = numeros[i];
  acumulador = acumulador + elemento;
  console.log(elemento);
}

console.log(acumulador);

let nuevoArreglo = numeros.slice(1, 5);
console.log(nuevoArreglo);

// posicion =>   0   1  2  3  4  5   6
// arreglo  => [10, 20, 30, 40, 50, 62]

// indice inicio , indice fin - 1
// 1, 5
// let ns = [10, 20, 30, 40, 50, 62];
// console.log(ns.slice(3, 5));

let ns = [10, 20, 30, 40, 50, 62];

let ultimo = ns.pop();

console.log(ultimo);

console.log(ns);

let principio = ns.shift();

console.log(principio);

console.log(ns);

ns.unshift(1000);

console.log(ns);

/**
 * push -> agrega un elemento al final del arreglo
 * pop -> elimina el ultimo elemento del arreglo
 * shift -> elimina el primer elemento del arreglo
 * unshift -> agrega un elemento al principio del arreglo
 * slice -> crea un nuevo arreglo a partir de un rango de elementos
 * length -> devuelve la cantidad de elementos del arreglo
 */

ns.forEach(function (numero) {
  console.log(numero);
});

//
for (let i = 0; i < ns.length; i++) {
  let elemento = ns[i];
  console.log(elemento);
}

// debemos tener un vector con 10 elementos
// debemos obtener la posicion del numero mayor

let vector = [15, 20, 256, 35, 40, 362, 705, 89, 75, 400];

let aux = vector[0]; // 15
let pos = 0;

for (let i = 0; i < vector.length; i++) {
  debugger;
  let numeroActual = vector[i];
  if (numeroActual > aux) {
    aux = numeroActual;
    pos = i;
  }
}

console.log(pos);
console.log(aux);

/**
 * Leer 10 enteros y almacenar en vector
 * determinar la posicion del numero par mayor
 */

let vector2 = [15, 201, 251, 35, 401, 361, 705, 89, 75, 401, '1002'];

let aux2 = 0;
let pos2 = 0;

for (let i = 0; i < vector2.length; i++) {
  let numeroActual = vector2[i];
  if (numeroActual % 2 === 0 && numeroActual > aux2) {
    aux2 = numeroActual;
    pos2 = i;
  }
}

if (aux2 === 0) {
  console.log('no hay numeros pares');
} else {
  console.log(pos2);
  console.log(aux2);
}

/**
 * Leer 10 enteros y almacenar en vector
 * determinar las posiciones de los elementos terminados en 4
 */

let vector3 = [15, 204, 251, 35, 404, 361, 704, 89, 75, 401];

for (let i = 0; i < vector3.length; i++) {
  let numeroActual = vector3[i];
  let ultimoDigito = numeroActual % 10;
  if (ultimoDigito === 4) {
    console.log(i);
  }
}
