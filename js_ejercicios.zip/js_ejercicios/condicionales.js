// ejercicio n°1
let numero ;

if (numero % 10 == 4 ){
    document.write("Numero termina en 4")
}
else{
    document.write("no termina en 4")
}

//ejercicio nº2
if (numero > -1000 && numero < -99){
    document.write("numero tiene 3 cifras")
}
else if(numero > 99 && numero < 1000){
    document.write("numero tiene 3 cifras")
}
 //ejericico nº3

if (numero < 0){
    document.write("Es negativo")
}

// ejercicio nº4
let digito1, digito2, suma

if (numero < 100 && numero > -100){
    digito1 = numero / 10 
    digito2 = numero % 10

    suma = digito1 + digito2 
    document.write(suma)
}