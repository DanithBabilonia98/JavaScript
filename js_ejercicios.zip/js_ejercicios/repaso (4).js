let persona = {
    nombre: 'Axel',
    apellido: 'Gonzalez',
    direccion: {
        calle: 'K104',
        casa: '2a',
        ciudad: 'Barranquilla'
    }
}
let persona2 = {
    nombre: 'bremys',
    apellido: 'Gnzalez',
    direccion: {
        calle: 'K102',
        casa: '2a',
        ciudad: 'Cartagena'
    }
}
let datos = {
    persona,
    persona2
}
console.log(datos.persona2.direccion.calle)

let {nombre, apellido, direccion} = persona;

let {calle, casa, ciudad} = direccion;

console.log(direccion);

console.log(calle, casa)
console.log('La direccion de la persona ' + nombre + ' es ' + ' ciudad: ' + ciudad + ' calle: ' + calle)

console.log(persona.direccion);

for (let i = 0; i < direccion.length; i++) {
    console.log(direccion[i]);
}