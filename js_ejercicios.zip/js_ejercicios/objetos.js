/**
 * Objetos
 * {clave => valor}
 */

let persona1 = {
  nombre: 'Juan',
  apellido: 'Perez',
  edad: 25,
  ciudad: 'Ciudad de Mexico',
};

console.log(persona1);

console.log(persona1['nombre']);

console.log(persona1['edad']);

console.log(persona1.nombre);

console.log(persona1.edad);

let persona2 = {
  apellido: 'Patricia',
  edad: 28,
  direccion: {
    departamento: 'Bolivar',
    ciudad: 'Cartagena',
    barrio: 'Daniel Lemaitre',
  },
  materiasCursadas: ['Matematicas', 'Fisica', 'Quimica'],
  nombre: 'Daniela',
  peso: 60,
  altura: 1.7,
  indiceMasaCorporal: function () {
    return this.peso / (this.altura * this.altura);
  },
};

console.log(persona2.materiasCursadas);
console.log(persona2.indiceMasaCorporal());

console.log(persona2);

console.log(persona1.nombre);
console.log(persona2.nombre);

console.log(persona2.direccion.departamento);

let objetoVacio = {};
console.log(objetoVacio);

/**
 * Promedio de las edades de los usuarios
 * El usuario con mas edad
 * El usuario con menos edad
 * La sumatoria de las edades
 */

let listadoUsuarios = [
  { nombre: 'Sandy', edad: 25 },
  { nombre: 'Juan', edad: 30 },
  { nombre: 'Pedro', edad: 35 },
  { nombre: 'Daniela', edad: 28 },
  { nombre: 'Jorge', edad: 40 },
  { nombre: 'Sandra', edad: 22 },
];

// Promedio de las edades de los usuarios
function promedioEdades() {
  let acumulado = 0;
  let totalUsuarios = listadoUsuarios.length;

  for (let i = 0; i < totalUsuarios; i++) {
    let usuarioActual = listadoUsuarios[i];
    acumulado += usuarioActual.edad;
  }

  let promedio = acumulado / totalUsuarios;
  console.log(promedio);
}

promedioEdades();

// El usuario con mas edad
function usuarioConMasEdad() {
  let totalUsuarios = listadoUsuarios.length;
  let usuario = { nombre: '', edad: 0 };

  for (let i = 0; i < totalUsuarios; i++) {
    let usuarioActual = listadoUsuarios[i];

    if (usuarioActual.edad > usuario.edad) {
      usuario = usuarioActual;
    }
  }

  console.log(
    `El usuario con mas edad es ${usuario.nombre} y tiene ${usuario.edad} años`,
  );
}

usuarioConMasEdad();

//El usuario con menos edad
function usuarioConMenorEdad() {
  let totalUsuarios = listadoUsuarios.length;
  let usuario = listadoUsuarios[0];

  for (let i = 0; i < totalUsuarios; i++) {
    let usuarioActual = listadoUsuarios[i];

    if (usuarioActual.edad < usuario.edad) {
      usuario = usuarioActual;
    }
  }

  console.log(
    `El usuario con la menor edad es ${usuario.nombre} y tiene ${usuario.edad} años`,
  );
}

usuarioConMenorEdad();

// La sumatoria de las edades
function sumatoriaEdades() {
  let totalUsuarios = listadoUsuarios.length;
  let acumuladorEdades = 0;

  for (let i = 0; i < totalUsuarios; i++) {
    let usuarioActual = listadoUsuarios[i];
    acumuladorEdades += usuarioActual.edad;
  }

  console.log(`La sumatoria de edades es ${acumuladorEdades} años`);
}

sumatoriaEdades();
