/**
 * Una inmobiliaria de una ciudad maneja una lista de inmuebles como la siguiente:

let inmobiliarias = [
  {año: 2000, metros: 100, habitaciones: 3, garaje: true, zona: 'A'},
  {año: 2012, metros: 60, habitaciones: 2, garaje: true, zona: 'B'},
  {año: 1980, metros: 120, habitaciones: 4, garaje: false, zona: 'A'},
  {año: 2005, metros: 75, habitaciones: 3, garaje: true, zona: 'B'},
  {año: 2015, metros: 90, habitaciones: 2, garaje: false, zona: 'A'}
];

Construir una función que permita hacer búsqueda de inmuebles en función de un presupuesto dado.

La función recibirá como entrada la lista de inmuebles y un precio,
y devolverá otra lista con los inmuebles cuyo precio sea menor o igual que el dado.

Los inmuebles de la lista que se devuelva deben incorporar un nuevo par a cada objeto con el precio del inmueble,
donde el precio de un inmueble se calcula con las siguiente fórmula en función de la zona:

Zona A: precio = (metros * 1000 + habitaciones * 5000 + garaje * 15000) * (1-año/100)

Zona B: precio = (metros * 1000 + habitaciones * 5000 + garaje * 15000) * (1-año/100) * 1.5
 */

let inmobiliarias = [
  { anio: 2000, metros: 100, habitaciones: 3, garaje: true, zona: 'A' },
  { anio: 2012, metros: 60, habitaciones: 2, garaje: true, zona: 'B' },
  { anio: 1980, metros: 120, habitaciones: 4, garaje: false, zona: 'A' },
  { anio: 2005, metros: 75, habitaciones: 3, garaje: true, zona: 'B' },
  { anio: 2015, metros: 90, habitaciones: 2, garaje: false, zona: 'A' },
];

function buscarInmuebles(listaInmuebles, presupuesto) {
  let inmueblesPresupuesto = [];

  for (let i = 0; i < listaInmuebles.length; i++) {
    let inmuebleActual = listaInmuebles[i];
    let precioInmuebleActual = calcularPrecioInmueble(inmuebleActual);
    inmuebleActual.precio = precioInmuebleActual;

    if (precioInmuebleActual <= presupuesto) {
      inmueblesPresupuesto.push(inmuebleActual);
    }
  }
  return inmueblesPresupuesto;
}

function calcularPrecioInmueble(inmueble) {
  let precio = 0;
  let { anio, metros, habitaciones, garaje, zona } = inmueble;

  if (zona === 'A') {
    precio =
      (metros * 1000 + habitaciones * 5000 + garaje * 15000) * (anio / 100 - 1);
  }

  if (zona === 'B') {
    precio =
      (metros * 1000 + habitaciones * 5000 + garaje * 15000) *
      (anio / 100 - 1) *
      1.5;
  }
  return precio;
}

let resultado = buscarInmuebles(inmobiliarias, 2_500_000);
console.log(resultado);

// Explicacion de destructuración de objetos en JS

let usuario = {
  nombre: 'Juan',
  edad: 30,
  direccion: {
    calle: 'Calle falsa 123',
    ciudad: 'Madrid',
    pais: 'España',
  },
};

// sin destructuración
// let nombre = usuario.nombre;
// let edad = usuario.edad;
// let direccion = usuario.direccion;

// con destructuración
let { edad, direccion, nombre } = usuario;

console.log(nombre);
console.log(edad);
console.log(direccion);
