let numeros = [101,50,102,25,11,10,44,101,4];

let cont = 0
for(let i = 0;i<numeros.length;i++){
     cont = 0
    for(let j=0;j<numeros.length;j++){
        if(numeros[i]===numeros[j]){  
            cont++;      
        }  
    } 
    console.log(cont);
    if(cont>1){
        console.log("almenos hay un repetido");
        break
    }
}

//leer 10 numeros enteros, almacernarlos en un vector y determinar si exite almenos
//un numero repetido

