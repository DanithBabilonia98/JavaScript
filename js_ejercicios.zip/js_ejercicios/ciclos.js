/**
 * for (of, in)
 * while
 */

/* for (let j = 1; j <= 10; j++) {
  console.log(`Tabla del ${j}`);
  for (let i = 0; i <= 10; i++) {
    console.log(` ${j} X ${i} = ${j * i}`);
  }
} */

// 0 1 1 2 3 5 8 13 21 34 55 ...

/*let a = 0;
let b = 1;

 console.log(a);
   console.log(b);
   for (let i = 0; i < 10; i++) {
      let c = a + b;
      console.log(c);
      a = b;
      b = c;
   }
 */

/* console.log(a);
for (let i = 0; i < 10; i++) {
  console.log(b);
  [a, b] = [b, a + b]
}
 */

/* let n = 25
let m = 30

let aux = n
n = m
m = aux

console.log(n);
console.log(m); */

/* let n = 25;
let m = 30;

[n, m] = [m, n]
console.log(n);
console.log(m); */

/* for (let i = 0; i < 10; i++) {}

let i = 0;
while (i < 10) {
  console.log(i);
  i++;
} */

/* for (let j = 1; j <= 10; j++) {
  console.log(`Tabla del ${j}`);
  for (let i = 0; i <= 10; i++) {
    console.log(` ${j} X ${i} = ${j * i}`);
  }
} */

let j = 1;
while (j <= 10) {
  console.log(`Tabla del ${j}`);
  let i = 0;
  while (i <= 10) {
    console.log(` ${j} X ${i} = ${j * i}`);
    i++;
  }
  j++;
}
