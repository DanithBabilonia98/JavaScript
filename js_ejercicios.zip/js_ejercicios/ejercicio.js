let a = 5;
let b = 3;
let c = -12;

console.log(a>3)
console.log(a>c)
console.log(a<c)
console.log(b<c)
console.log(b != c)
console.log(a == 3)
console.log(a*b == 15)
console.log(a*b == -30)
console.log(c/b<a)
console.log(c/b == -10)
console.log(c/b == -4)
console.log(a+b+c == 5)
console.log((a + b == 8) && (a-b == 2))
console.log((a+b == 8)|| (a-b ==6))
console.log(a>3 && b>3&& c<3)
console.log(a >3 && b >=3 && c<-3)