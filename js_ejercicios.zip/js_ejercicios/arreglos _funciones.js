/*let objeto ={
    cedula: '12345679',
}*/

let arreglo =[
    "1",
    2,
    3,
    4,
    5,
    8,
];
console.log(arreglo);

let numer = [1,2];
console.log(numer === [1,2]);
