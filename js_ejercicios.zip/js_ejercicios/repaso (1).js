let vector = [];
let cont = 0
limite = 0
for (let i = 100; i<=300;i++){
    cont = 0
    for(let j = 1;j <=i;j++){
        if(i%j==0){
        cont = cont + 1
        }
    }
    if(cont==2){
        vector.push(i)
        limite++;
    }
    if(limite==10){
        break
    }
}
    console.log(vector)




