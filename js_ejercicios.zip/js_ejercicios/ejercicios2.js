/*Calcular la cantidad de empleados que merecen auxilio de transporte;
y a quienes se le debe hacer una retención del 10%
 para x cantidad de empleados*/

 let horas_trabajadas, valor_hora, cantidad_empleados;
 let salarioMin = 1000000;
 let contador1 = 0 ;
 let contador2 = 0;

cantidad_empleados= prompt("Ingrese la cantidad de empleados con los que cuenta su empresa");

for (i in cantidad_empleados){
     document.write("Empleado ", i)
     horas_trabajadas = prompt("Ingrese la cantidad de horas que trabajó");
     valor_hora = prompt("Ingrese el valor de la hora que trabajó");

     salario = horas_trabajadas * valor_hora;

     if (salario <= salarioMin){
         salario = salario + 117000
         document.write("Empleado nº: ", i, "su salario es : ", salario)
         contador1 = contador1 + 1;
     }
     else
     if(salario > (salarioMin * 4)){
         salario = salario*0.9
         document.write("Empleado nº: ",i,"su salario es: ", salario)
         contador2 = contador2 + 1
     }
}
document.write("La cantidad de empleados que recibirán auxilio de transporte es :", contador1);
document.write("La cantidad de empleados que se les hará retención en la fuente es : ", contador2);

 