/**
 * Matrices
 */
let vector = [1, 2, 3];

// matrix 4 x 4
let matrix = [
  [0, 0, 0, 1],
  [0, 0, 1, 0],
  [0, 1, 0, 0],
  [1, 0, 0, 0],
];

let filas = matrix.length;
let columnas = matrix[0].length;

console.log(filas);
console.log(columnas);

for (let i = 0; i < filas; i++) {
  for (let j = 0; j < columnas; j++) {
    if (i + j === 3) {
      matrix[i][j] = 1;
    }
  }
}

console.log(matrix);

function numeroMayorMatrix(matrix1, cantFilas, cantColumnas) {
  let numeroMayor = 0;
  let fila = null;
  let columna = null;

  for (let i = 0; i < cantFilas; i++) {
    for (let j = 0; j < cantColumnas; j++) {
      let valorActual = matrix1[i][j];
      if (valorActual > numeroMayor) {
        numeroMayor = valorActual;
        fila = i;
        columna = j;
      }
    }
  }
  return [numeroMayor, fila, columna];
}

let matrix1 = [
  [25, 32, 1, 5],
  [1, 2, 3, 4],
  [1, 220, 36, 441],
  [17, 28, 34, 41],
];

let resultados = numeroMayorMatrix(matrix1, 4, 4);
console.log(
  `El numero mayor es ${resultados[0]} en la posicion [${resultados[1]}, ${resultados[2]}]`,
);

matrix1 = [
  [25, 32, 1],
  [1, 2, 3],
  [1, 220, 36],
];

resultados = numeroMayorMatrix(matrix1, 3, 3);
console.log(
  `El numero mayor es ${resultados[0]} en la posicion [${resultados[1]}, ${resultados[2]}]`,
);

function posicionNumerosParesMatrix(matrix) {
  for (let i = 0; i < matrix.length; i++) {
    for (let j = 0; j < matrix[0].length; j++) {
      let elementoActual = matrix[i][j];
      if (elementoActual % 2 === 0) {
        console.log(
          `El numero par es ${matrix[i][j]} en la posicion [${i}, ${j}]`,
        );
      }
    }
  }
}

let matrix2 = [
  [1, 2, 3, 4],
  [5, 6, 7, 8],
  [10, 11, 12, 13],
];

posicionNumerosParesMatrix(matrix2);

// numeros primos del 1 al 100 => 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43
// solucion Juan Jose

let matrix3 = [
  [1, 2, 3],
  [5, 6, 7],
  [10, 19, 12],
  [10, 51, 43],
];

for (let i = 0; i < matrix3.length; i++) {
  for (let j = 0; j < matrix3[0].length; j++) {
    let elementoActual = matrix3[i][j];
    if (elementoActual < 2) {
      continue;
    } else {
      let divisores = 0;
      for (let k = 1; k < elementoActual; k++) {
        if (elementoActual % k === 0) {
          divisores++;
        }
      }
      if (divisores <= 2) {
        console.log(
          `El numero ${elementoActual} es primo esta en la posicion [${i}, ${j}]`,
        );
      }

      divisores = 0;
    }
  }
}

// Solucion 2
function esPrimo(numero = 2) {
  if (numero < 2) {
    return false;
  }

  for (let i = 2; i < numero; i++) {
    if (numero % i === 0) {
      return false;
    }
  }
  return true;
}

function obtenerPrimosMatrix(matrix) {
  for (let i = 0; i < matrix.length; i++) {
    for (let j = 0; j < matrix[0].length; j++) {
      let elementoActual = matrix[i][j];
      if (esPrimo(elementoActual)) {
        console.log(
          `El numero ${elementoActual} es primo esta en la posicion [${i}, ${j}]`,
        );
      }
    }
  }
}

let matrix4 = [
  [1, 2, 3],
  [5, 6, 7],
  [10, 19, 12],
  [10, 51, 43],
];

obtenerPrimosMatrix(matrix4);
