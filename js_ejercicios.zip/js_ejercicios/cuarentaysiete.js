let vector = [15,2,3,40,5,1,70,8,9,1070];

for (let index = 0; index < vector.length; index++) {
    let elementoActual = vector[index].toString();
    if(parseInt(elementoActual[elementoActual.length - 1]) === 0){
        console.log('un multiplo de 10 en la posición:', index);
    }
}
