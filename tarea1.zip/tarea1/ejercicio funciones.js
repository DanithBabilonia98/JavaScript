/**
 * ejercicio objetos
 *
 * Fabricantes (id, nombre)
 * Articulos (id, nombre, precio, fabricante)
 *
 * 1) Obtener todos los datos de los articulos cuyo precio esten entre 90_000 y 260_000
 *
 * 2) Obtener el nombre y el precio de los articulos cuyo precio sea mayor o igual a 200_000 y
 *  ordenar descendentemente por precio.
 *
 * 3) Obtener un listado completo de articulos
 *
 * 4) Obtener el numero de articulos cuyo precio sea mayor o igual a 150_000
 *
 * 5) Obtener el precio medio de los articulos
 *
 * 6) aplicar un descuento de 2000 a todos los articulos cuyo precio sea mayor o igual a 180_000
 */

let fabricantes = {
  protex: {
    id: 1,
    nombre: 'Protex',
  },
  azucar_manuelita: {
    id: 2,
    nombre: 'Manuelita',
  },
};

let articulos = [
  {
    id: 10,
    nombre: 'Protex',
    precio: 258500,
    fabricante: fabricantes.protex,
  },
  {
    id: 11,
    nombre: 'Azucar Manuelita',
    precio: 125000,
    fabricante: fabricantes.azucar_manuelita,
  },
  {
    id: 12,
    nombre: 'Jabon canalita',
    precio: 1985000,
    fabricante: fabricantes.protex,
  },
];

// 1) Obtener todos los datos de los articulos cuyo precio esten entre 90_000 y 260_000

function articulosEnRangoNoventaDoscientoASesenta(datos) {
  let articulos = [];

  for (let i = 0; i < datos.length; i++) {
    let articuloActual = datos[i];
    if (articuloActual.precio >= 90000 && articuloActual.precio <= 260000) {
      articulos.push(articuloActual);
    }
  }

  return articulos;
}


/**
 * 2) Obtener el nombre y el precio de los articulos cuyo precio sea mayor o igual a 200_000 y ordenar descendentemente por precio.
 */
function articulosMayorIgualA200(datos) {
  let articulos = [];

  for (let i = 0; i < datos.length; i++) {
    if (datos[i].precio >= 200000) {
      let articuloActual = {
        nombre: datos[i].nombre,
        precio: datos[i].precio,
      };
      articulos.push(articuloActual);
    }
  }

  let articulosOrdenados = articulos.sort(function ordenar(actual, siguiente) {
    return actual.precio - siguiente.precio;
  });

  return articulosOrdenados;
}


//  3) Obtener un listado completo de articulos
function listadoArticulos() {
  let Listado = document.getElementById('listado-articulos');
  let filasTabla4 =  ``;
  for (let i = 0; i < articulos.length; i++) {
    //console.log(`${datos[i].id} - ${datos[i].nombre} - ${datos[i].precio}`);
  let {id, nombre, precio} = articulos[i];
  filasTabla4 += `
    <tr>
      <td>${id}</td>
      <td>${nombre}</td>
      <td>${precio}</td>
      <td><button type="button" class="btn btn-outline-primary btn-sm" onclick="actualizarArticulo(${id})">Editar</button></td>
      <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="borrarArticulo(${id})">Eliminar</button>
      </td>
    </tr>
  `;
 
  }
  Listado.innerHTML = filasTabla4;
}

listadoArticulos();

//Función para crear un nuevo artículo
function crearArticulo(nombre, precio, fabricante) {
  let id = articulos.length + 1;
  let articulo = {
    id,
    nombre,
    precio, 
    fabricante ,
  };
  articulos.push(articulo);
}
function borrarArticulo(id) {
  for (let i = 0; i < articulos.length; i++) {
    if (articulos[i].id === id) {
      articulos.splice(i, 1);
    }
  }
  listadoArticulos();
}
//Editar
function editarArticulo(id, nuevoNombre, precio, fabricante) {
  for (let i = 0; i < articulos.length; i++) {
    if (articulos[i].id === id) {
      articulos[i].nombre = nuevoNombre;
      articulos[i].precio = precio;
      articulos[i].fabricante = fabricante;
    }
  }
}

function actualizarArticulo(id) {
  let nombre = prompt('Ingrese el nuevo nombre:');
  let precio = prompt('Ingrese el nuevo precio:');
  let fabricante = prompt('Ingrese el nuevo fabricnate:');

  editarArticulo(id, nombre, precio, fabricante);
  listadoArticulos();
}

//Función para registtrar o crear un nuevo fabricante

function crearFabricante(nombre){
  let id = fabricantes.length + 1 ;
  let fabricante = {
    id,
    nombre,
  };
  fabricantes.push(fabricante);
}

/**
 * Crear artículo 
 */
let btnCrearArticulo = document.getElementById('btnCrearArticulo');

btnCrearArticulo.addEventListener('click', function (e) {
  let formularioCrearArticulo = document.getElementById('crear-articulo');

  let { nombre, precio, fabricante } = formularioCrearArticulo.elements;

  crearArticulo(nombre.value, precio.value, fabricante.value);
  formularioCrearArticulo.reset();

  listadoArticulos();
  MostrarCantidadArticulosMayorIgual150();
  listarArticulosNoventa_DoscientosSesenta();
  ListadoProductosDescuento();
});

//HTML CrearFabricante
let btnCrearFabricante = document.getElementById('btnCrearFabricante');

btnCrearArticulo.addEventListener('click', function (e) {
  let formularioCrearFabricante = document.getElementById('crear-fabricante');

  let { nombre} = formularioCrearFabricante.elements;

  crearFabricante(nombre.value);
  formularioCrearFabricante.reset();

  listarFabricantes();
});

//Listado de los fabricantes
function listarFabricantes() {
  let Listado = document.getElementById('listado-fabricantes');
  let tablas =  ``;
  for (let i = 0; i < fabricantes.length; i++) {
    //console.log(`${datos[i].id} - ${datos[i].nombre} - ${datos[i].precio}`);
  let {id, nombre} = fabricantes[i];
  tablas+= `
    <tr>
      <td>${id}</td>
      <td>${nombre}</td>
    </tr>
  `;
 
  };
  Listado.innerHTML = tablas;
}
//Mostrar los datos ordenados 

function ArticulosOrdenados(){
  salida = articulosMayorIgualA200(articulos);
  let ArticulosMayores200 = document.getElementById('listado_200');
  let filasTabla3 = ``;

  for (let i = 0; i < salida.length; i++) {
    let {nombre, precio}= salida[i];
    filasTabla3 += `
    <tr>
      <td>${nombre}</td>
      <td>${precio}</td>
    </tr>
    `;
  };
  ArticulosMayores200.innerHTML = filasTabla3;
  listadoArticulos();

}
ArticulosOrdenados()

/**
 * 4) Obtener el numero de articulos cuyo precio sea mayor o igual a 150_000
 */
function articulosMayorIgualA150(datos) {
  let contador = 0;
  for (let i = 0; i < datos.length; i++) {
    let valorActual = datos[i];
    if (valorActual.precio >= 150000) {
      contador++;
    }
  }
  return contador;
}

//  5) Obtener el precio medio de los articulos
function precioMedio(articulos) {
  let suma = 0;
  let cantidadArticulos = articulos.length;
  for (let i = 0; i < cantidadArticulos; i++) {
    suma += articulos[i].precio;
  }
  return suma / cantidadArticulos;
}

/**
 * 6) aplicar un descuento de 2000 a todos los articulos cuyo precio sea mayor o igual a 180_000
 */
function aplicarDescuento(articulos) {
  for (let i = 0; i < articulos.length; i++) {
    let articuloActual = articulos[i];
    if (articuloActual.precio >= 180_000) {
      articuloActual.precio -= 2000;
      // articuloActual.precio = articuloActual.precio - 2000;
    }
  }
  return articulos;
}

//Listado de productos que tienen descuento
function ListadoProductosDescuento() {
  let salida = aplicarDescuento(articulos);
  let ListaProductosDescuento = document.getElementById('listado-descuento');
  let filasTabla2 = ``;

  for (i = 0; i < salida.length; i++) {
    let { id, nombre, precio } = salida[i];
    filasTabla2 += `
    <tr>
      <td>${id}</td>
      <td>${nombre}</td>
      <td>${precio}</td>
    </tr>
    `;
  }
  ListaProductosDescuento.innerHTML = filasTabla2 ;
}


//Retornar o listar los articulos que están entre noventa mil y doscientos sentata mil
function listarArticulosNoventa_DoscientosSesenta() {
  let salida = articulosEnRangoNoventaDoscientoASesenta(articulos);
  let ListadoNoventaDoscientosSesenta = document.getElementById('listado_90-260');
  let filasTabla1 = ``;

  for (let i = 0; i < salida.length; i++) {
    let { id, nombre, precio, fabricante } = salida[i];
    filasTabla1 += `
      <tr>
      <td>${id}</td>
      <td>${nombre}</td>
      <td>${precio}</td>
      <td>${fabricante.nombre}</td>
      </tr>
      `;
  }
  ListadoNoventaDoscientosSesenta.innerHTML = filasTabla1;

}

//Mostrar el precio promedio de los articulos 
function PrecioMedioMostrar() {
  salida = precioMedio(articulos);
  let PrecioMedio = document.getElementById('precio_medio-articulos');
  let tarjeta = `
  <div class="col-sm-3 mb-1" style="width: 18rem;">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title">Precio Medio de Artículos </h5>
          <p class="card-text">${salida}</p>
      </div>
  </div>
</div>`;

  PrecioMedio.innerHTML = tarjeta;

}


//Cantidad de Artículos mayores o iguales a 150_000 
function MostrarCantidadArticulosMayorIgual150() {
  salida = articulosMayorIgualA150(articulos);
  let CantidadArticulosMayores150 = document.getElementById('cantidad-articulos');
  let tarjetaCantidad = `
  <div class="col-sm-3 mb-1" style="width: 18rem;">
  <div class="card">
      <div class="card-body" class="col-sm-3 mb-1">
          <h5 class="card-title">Cantidad de Artículos mayores o iguales a 150000</h5>
          <p class="card-text">${salida}</p>
      </div>
  </div>
</div>
  `;
  CantidadArticulosMayores150.innerHTML = tarjetaCantidad;
}

MostrarCantidadArticulosMayorIgual150();
PrecioMedioMostrar();
listarArticulosNoventa_DoscientosSesenta();
ListadoProductosDescuento();