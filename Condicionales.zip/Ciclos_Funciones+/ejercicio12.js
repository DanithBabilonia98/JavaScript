function Encontrar_Digito_1(num){
    if(num[0]==1){
        console.log("El número 1 se encuentra en la primera posición")
    }else if(num[1]==1){
        console.log("El número 1 se encuentra en la segunda posición")
    }else if(num[2]==1){
        console.log("El número 1 se encuentra en la tercera posición")
    }else{
        console.log("No se encuentra el número 1")
    }
}
Encontrar_Digito_1("231");