function Numeros_Pares(num){
    cadena = "Los números pares son:\n"
    for (var i = 1; i <= num; i++) {
        if(i%2==0){
            cadena += "\n"+i
        }
    }
    console.log(cadena);

}

Numeros_Pares(6);
		