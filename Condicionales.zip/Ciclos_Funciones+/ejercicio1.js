function numerosEnteros(num) {
    
    cadena = "Los números enteros son:\n"
    for (var i = 1; i <= num; i++) {
        cadena += "\n" + i
    }
    return (cadena);
}
console.log(numerosEnteros(5));