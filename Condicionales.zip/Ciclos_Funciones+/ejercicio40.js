function Pertenece_Serie_Fibonacci(num) {
    num1 = 0
    num2 = 1
    suma = 1
    p = true
    pertenece = false
    while (p) {
        suma = num1 + num2
        num1 = num2
        num2 = suma
        if (suma == num) {
            pertenece = true
        }
        if (suma >= 100) {
            p = false
        }
    }
    if (pertenece == true) {
        console.log("El número " + num + " si pertenece a la serie fibonacci")
    } else {
        console.log("El número " + num + " no pertenece a la serie fibonacci")
    }
}
Pertenece_Serie_Fibonacci(56);