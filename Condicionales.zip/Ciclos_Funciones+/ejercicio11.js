function Enteros_Entre_X_Y(num) {

    for (let i = parseInt(num[0]); i <= parseInt(num[1]); i++) {
        console.log(i)
    }

}
Enteros_Entre_X_Y("15");