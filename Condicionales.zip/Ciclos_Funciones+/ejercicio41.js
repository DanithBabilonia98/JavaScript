function sumaElementosFibonacci() {
    num1 = 0;
    num2 = 1;
    suma = 1;
    total = 0;
    cant = 0;
    p = true;
    console.log("La suma fibonacci entre 0 y 1000 es:<br>")
    while (p) {
        suma = num1 + num2;
        num1 = num2;
        num2 = suma;
        total += suma;
        cant++ ;
        if (suma >= 1000) {
            p = false;
        }
    }
    console.log(total);
}
sumaElementosFibonacci();