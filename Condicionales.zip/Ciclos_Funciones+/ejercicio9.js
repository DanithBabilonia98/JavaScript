function Numeros_Terminados_en6() {
    for (let i = 25; i <= 205; i++) {
        if (i % 10 == 6) {
            console.log(i);
        }
    }
}
Numeros_Terminados_en6();