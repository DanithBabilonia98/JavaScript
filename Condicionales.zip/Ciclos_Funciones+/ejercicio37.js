function tablas_multiplicar(){
    for (var i = 1; i <= 10; i++) {
        console.log("Tabla del "+i)
        for (var j = 1; j <= 10; j++) {
            console.log(`${i}x${j} = ${i*j}`);
        }
    }
}
tablas_multiplicar();