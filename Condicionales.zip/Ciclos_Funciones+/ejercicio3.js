function Divisores_Exactos(num) {
    	cadena = "Los divisores exactos son:\n"
		for (var i = 1; i <= num; i++) {
			if(i%2==0){
				cadena += "\n"+i
			}
		}
		console.log(cadena);
}
Divisores_Exactos(8);