function NumerosEntre_1_y_100(){
    for(let i=1; i <= 100; i++){
        console.log(i);
    }
}
NumerosEntre_1_y_100();