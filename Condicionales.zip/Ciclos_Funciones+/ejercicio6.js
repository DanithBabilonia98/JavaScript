function NumerosComprendidos_Entre1_Ycada_Digito(num){
    cadena = "Números enteros del 1 al "+num[0]
		for (var i = 1; i <= num[0]; i++) {
			cadena += "\n" + i
		}
		console.log(cadena)
		cadena = "Números enteros del 1 al "+num[1]
		for (var i = 1; i <= num[1]; i++) {
			cadena += "\n" + i
		}
		console.log(cadena)
		cadena = "Números enteros del 1 al "+num[2]
		for (var i = 1; i <= num[2]; i++) {
			cadena += "\n" + i
		}
		console.log(cadena)
}
NumerosComprendidos_Entre1_Ycada_Digito("345");