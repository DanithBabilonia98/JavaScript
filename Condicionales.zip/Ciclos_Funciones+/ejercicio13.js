function multiplos_de_cinco(num){
    for (let i= 1 ; i <= num ; i++){
        if(i%5 == 0){
            console.log(i)
        }
    }
}

multiplos_de_cinco(35)