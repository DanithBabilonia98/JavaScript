function Numeros_Terminados_En4(num1, num2){
    console.log("Los números terminados en 4 son:")
		for (var i = num1; i <= num2; i++) {
			if(i%10 == 4){
				console.log(i);		
			}
		}
}
Numeros_Terminados_En4(4,26);