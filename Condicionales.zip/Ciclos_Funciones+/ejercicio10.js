function sumaEnteros(num){
    console.log("La suma es:")
    let suma=0;
    for (let i = 1; i <= num; i++) {
        suma += i
    }
    console.log(suma);
}
sumaEnteros(20);