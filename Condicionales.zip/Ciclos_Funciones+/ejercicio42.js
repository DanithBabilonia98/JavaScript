function promedioFibonacci(){
    let num1 = 0
		let num2 = 1
		let suma = 1
		let total = 0
		let cant = 0
		let p = true
		
		while(p){
			suma = num1 + num2
			num1 = num2
			num2 = suma
			total += suma
			cant++
			if(suma >= 1000){
				p = false
			}
		}
		console.log("El promedio es "+parseInt(total/cant))
}
promedioFibonacci()