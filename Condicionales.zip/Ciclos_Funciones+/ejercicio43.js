function cantidadElementos() {
    let num1 = 0
    let num2 = 1
    let suma = 1
    let p = true
    let cant = 0
    let num = 0
    while (p) {
        if (suma > 2000) {
            p = false
        }
        if (suma >= 1000 && suma <= 2000) {
           
            num = suma
            cant++
        }
        suma = num1 + num2
        num1 = num2
        num2 = suma
    }
    console.log("El total de números fibonacci entre 1000 y 2000 es de " +  num);
}
cantidadElementos()