function Enteros_Comprendidos_Entre2_Numeros(num1=0, num2){
    cadena = "Los números enteros son:\n"
		for (var i = num1; i <= num2; i++) {
			cadena += "\n"+i
		}
		console.log(cadena)
}
Enteros_Comprendidos_Entre2_Numeros(2,10);