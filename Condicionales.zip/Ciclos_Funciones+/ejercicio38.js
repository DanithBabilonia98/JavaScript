function tabla_multiplicar(num){
    console.log("Tabla del "+num)
		for (var i = 1; i <= 10; i++) {
			console.log(`${num}x${i} = ${num*i}`)
		}
}
tabla_multiplicar(10);