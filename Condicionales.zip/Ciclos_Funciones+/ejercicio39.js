function serieFibonnaci(){
    num1 = 0
		num2 = 1
		suma = 1
		p = true
		while(p){
			console.log(suma)
			suma = num1 + num2
			num1 = num2
			num2 = suma
			if(suma >= 10000){
				p = false
			}
		}
}

serieFibonnaci();