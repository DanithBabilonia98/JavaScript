//BackEnd para la página principal

let inmuebles = [
    { id: 001, anio: 2000, metros: 100, habitaciones: 3, garage: true, zona: 'A' },
    { id: 002,  anio: 2012, metros: 60, habitaciones: 2, garage: true, zona: 'B' },
    { id: 003,  anio: 1980, metros: 120, habitaciones: 4, garage: false, zona: 'A' },
    { id: 004, anio: 2005, metros: 75, habitaciones: 3, garage: true, zona: 'B' },
    { id: 005, anio: 2015, metros: 90, habitaciones: 2, garage: false, zona: 'A' },
  ];
//Función para crear inmuebles

function crearInmuebles(anio,metros, habitaciones, zona){
    let id = inmuebles.length + 1;
    let inmueble = {
        id,
        anio,
        metros,
        habitaciones,
        garage :false ,
        zona,
    };
    inmuebles.push(inmueble);
}

//Función para borrar inmuebles
function borrarInmueble(id){
    for(let i = 0 ; i < inmuebles.length ; i++){
        if(inmuebles[i].id== id){
            inmuebles.splice(i,i);
        }
    }
    listarInmuebles();
}

//Funcion para editar 
function editarInmuebles(id, nuevoAnio, nuevoMetros, nuevoCantidadHabitaciones, garageNuevo, nuevaZona){
    for(let i = 0 ; i < inmuebles.length ; i++){
        if(inmuebles[i] == id){
            inmuebles[i].anio = nuevoAnio;
            inmuebles[i].metros = nuevoMetros;
            inmuebles[i].habitaciones = nuevoCantidadHabitaciones ;
            inmuebles[i].garage = garageNuevo;
            inmuebles[i].zona = nuevaZona;
        }
    }
}

//Js y Html

//función listar
function listarInmuebles(){
    let listadoInmuebles = document.getElementById('lista-inmueble');
    let filas =``;
    for (let i = 0; i < inmuebles.length ; i++){
        let {id, anio, metros, habitaciones, garage, zona}= inmuebles[i];
        let badged = '';

        if (garage) {
        badged = "<span class='badge bg-success'>Tiene</span>";
        } else {
        badged = "<span class='badge bg-warning text-dark'>No tiene</span>";
        }   
        filas +=`
        <tr>
            <th scope = "row">${id}</th>
            <td>${anio}</td>
            <td>${metros}</td>
            <td>${habitaciones}</td>
            <td>${badged}</td>
            <td>${zona}</td>
            <td>
            <button type="button" class="btn btn-outline-primary btn-sm" onclick="actualizarInmueble(${id})">Editar</button>
            
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="borrarInmueble(${id})">Eliminar</button>
            </td>
        </tr>`;
    }
    listadoInmuebles.innerHTML = filas;
}

// botón para crear un nuevo inmueble
let btnCrearInmueble = document.getElementById('btnCrearInmueble');

btnCrearInmueble.addEventListener('click', function (e) {
  let formularioCrearInmueble = document.getElementById('formularioInmuebles');

  let { anio, metros, habitaciones,zona } = formularioCrearInmueble.elements;

  crearInmuebles(anio.value, metros.value, habitaciones.value,  zona.value);
  formularioCrearInmueble.reset();

  listarInmuebles();
});

//Función para actualizar 
function actualizarInmueble(id) {
    let anio = prompt('Ingrese el nuevo año:');
    let metros = prompt('Ingrese la nueva cantidad de metros :');
    let habitaciones = prompt('Ingrese la nueva cantidad de habitaciones :');
    let garageNuevo = prompt('Ingrese si tiene o no garage :');
    let zona = prompt('Ingrese la nueva zona :');
    let garage = false;
  
    if (garageNuevo === 'true') {
      garage = true;
    }
  
    editarInmuebles(id,anio, metros, habitaciones, garage, zona);
    listarInmuebles();
  }

console.log("está funcionando");
listarInmuebles();